#!/bin/bash

echo "Running Memory Allocation Visualizer..."
python3 main.py
